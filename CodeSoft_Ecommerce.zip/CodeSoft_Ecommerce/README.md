# Forma · Simple E-commerce Store

A complete CodeAlpha full-stack internship project.

## Task 1 features

- Eight database-backed products with categories, search and price sorting.
- Dedicated product detail views with shareable `#product-ID` URLs.
- Browser-persisted shopping cart, quantity controls and item removal.
- User registration, login/logout and profile editing.
- Address validation, transactional order creation, server-calculated totals and stock deduction.
- Private order history with stored item names/prices and confirmation status.
- Responsive layout; mobile order navigation.

**Important:** Checkout is a simulation. There is no payment gateway, actual delivery, shipping fee, separate tax calculation or administration panel. Prices are integer paise in the database and displayed in INR. Product art is illustrative SVG; the hero photograph is AI-generated.

## Database

- `users`: identity, password hash, bio and avatar color.
- `sessions`: server-side login sessions.
- `products`: catalog, category, integer price, description, art identifier, color, stock.
- `orders`: customer, total, delivery address, status, timestamp.
- `order_items`: order/product references plus immutable name, price, and quantity snapshots.

The cart is in browser local storage, not the database. Stock checks, order/item creation, and stock deduction run in a single SQLite transaction. Client-supplied prices are ignored. Each user can read only their own orders.

## Store API

| Method | Endpoint            | Behavior                                                |
| ------ | ------------------- | ------------------------------------------------------- |
| GET    | `/api/products`     | List products                                           |
| GET    | `/api/products/:id` | Product details                                         |
| GET    | `/api/orders`       | Current user’s orders and line items                    |
| POST   | `/api/orders`       | Create order; body `{address, items: [{id, quantity}]}` |

Quantity is restricted to 1–20 per product, subject to remaining stock. Duplicate product lines and invalid/empty orders are rejected.

## Demonstration checklist

1. Search for “bottle”, try categories and price sorting.
2. Open a product, add it to the bag, change quantity, and remove an item.
3. Register or sign in. Check out using a **fictional** complete address.
4. View the order in My orders, then sign out.
5. Sign in with another account and verify that its order history is separate.

## Setup

Install Node.js 20 or 22 LTS and npm. In this folder:

```bash
npm ci
npm start
```

Open **http://localhost:3001**. The database and demo data are created automatically. Do not open `public/index.html` directly; run the server. No database service, API key, or build step is needed.

**Demo login:** `demo@example.com` / `Demo12345!` (or use the one-click demo button). `maya@example.com`, `jordan@example.com`, and `sam@example.com` share that demo password. You can register new users. All names, products, and seeded content are fictional examples.

## Stack and structure

- Frontend: HTML, responsive CSS, vanilla JavaScript, Fetch API.
- Backend: Express.js, parameterized SQL through better-sqlite3.
- Auth: bcrypt, regenerated cookie sessions, SQLite session storage, auth attempt rate limits.
- `backend.js`: authentication, validation helpers, middleware and session storage.
- `server.js`: schema, sample data, project API routes and server entry point.
- `public/app.js` / `style.css`: project UI and behavior.
- `public/common.js` / `common.css`: account dialogs and shared UI primitives.

## Common API

Every path below is relative to the server root. In the optional collection launcher, prefix the project mount path. JSON request bodies are used. Include `X-App-Request: 1` on every POST, PATCH, or DELETE and keep the session cookie. There is no cross-origin API policy.

| Method | Endpoint             | Purpose                                                  |
| ------ | -------------------- | -------------------------------------------------------- |
| GET    | `/api/me`            | Current session user or null                             |
| POST   | `/api/auth/register` | Create account: name, email, password (8–72 characters)  |
| POST   | `/api/auth/login`    | Sign in: email, password                                 |
| POST   | `/api/auth/logout`   | Destroy the session                                      |
| PATCH  | `/api/profile`       | Update own name and bio                                  |
| GET    | `/api/users?q=...`   | Registered names/bios for authenticated users, up to 100 |

## Persistence, environment and safety

`data/app.sqlite` persists application records and sessions. A random secret is created at `data/.session-secret` unless `SESSION_SECRET` is set. Both are excluded from Git. Stop the server and delete `data/` to reset the demo; this erases local data.

Optional environment variables: `PORT`, `DATA_DIR` (a parent folder for this app’s data subdirectory), `SESSION_SECRET`, `COOKIE_SECURE=1` for HTTPS cookies, and `TRUST_PROXY=1` behind a trusted single-hop proxy. See `.env.example`. Variables must be exported or configured in the host; there is no automatic dotenv loader.

For public hosting, remove demo credentials and buttons, add email verification/recovery and broader abuse protection, enable HTTPS with secure cookies, configure frame restrictions, and use persistent storage/backups. This is an internship demonstration, not a production service. A single SQLite-backed server is intended; use a shared database and sessions when scaling horizontally.

## Testing

The full collection includes `tests/integration.js` (47 assertions across all three projects) and optional Playwright workflows in `tests/browser-smoke.js`. Run them from the collection root as described in its README. For this standalone repository, use the manual demonstration checklist below.
