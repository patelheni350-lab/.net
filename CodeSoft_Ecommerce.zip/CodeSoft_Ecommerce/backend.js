const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
function fail(message, status = 400) {
  const e = new Error(message);
  e.status = status;
  throw e;
}
function text(v, name, max = 500, min = 1) {
  if (typeof v !== "string" || v.trim().length < min || v.trim().length > max)
    fail(`${name} must be ${min}–${max} characters.`);
  return v.trim();
}
function integer(v, name, min = 1, max = 100000000) {
  if (!Number.isInteger(Number(v)) || Number(v) < min || Number(v) > max)
    fail(`Invalid ${name}.`);
  return Number(v);
}
function setup(dir, name) {
  const folder = process.env.DATA_DIR
    ? path.join(process.env.DATA_DIR, name)
    : path.join(dir, "data");
  fs.mkdirSync(folder, { recursive: true });
  const db = new Database(path.join(folder, "app.sqlite"));
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.pragma("busy_timeout = 5000");
  db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '#7956d8', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS sessions(sid TEXT PRIMARY KEY, data TEXT NOT NULL, expires INTEGER NOT NULL);`);
  class Store extends session.Store {
    get(sid, cb) {
      try {
        const r = db
          .prepare("SELECT data FROM sessions WHERE sid=? AND expires>?")
          .get(sid, Date.now());
        cb(null, r ? JSON.parse(r.data) : null);
      } catch (e) {
        cb(e);
      }
    }
    set(sid, s, cb = () => {}) {
      try {
        db.prepare("INSERT OR REPLACE INTO sessions VALUES(?,?,?)").run(
          sid,
          JSON.stringify(s),
          Date.now() + 7 * 86400000,
        );
        db.prepare("DELETE FROM sessions WHERE expires<?").run(Date.now());
        cb();
      } catch (e) {
        cb(e);
      }
    }
    destroy(sid, cb = () => {}) {
      try {
        db.prepare("DELETE FROM sessions WHERE sid=?").run(sid);
        cb();
      } catch (e) {
        cb(e);
      }
    }
    touch(sid, s, cb = () => {}) {
      this.set(sid, s, cb);
    }
  }
  let secret = process.env.SESSION_SECRET;
  if (!secret) {
    const f = path.join(folder, ".session-secret");
    if (!fs.existsSync(f))
      fs.writeFileSync(f, crypto.randomBytes(48).toString("hex"), {
        mode: 0o600,
      });
    secret = fs.readFileSync(f, "utf8");
  }
  const app = express();
  app.locals.db = db;
  app.disable("x-powered-by");
  if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", "data:"],
          connectSrc: ["'self'"],
          frameAncestors: null,
          upgradeInsecureRequests: null,
        },
      },
      frameguard: false,
    }),
  );
  app.use(express.json({ limit: "64kb" }));
  app.use(
    session({
      name: `ca_${name}`,
      secret,
      resave: false,
      saveUninitialized: false,
      store: new Store(),
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.COOKIE_SECURE === "1",
        maxAge: 7 * 86400000,
      },
    }),
  );
  app.use("/api", (req, res, next) => {
    res.set("Cache-Control", "no-store");
    if (
      !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
      req.get("X-App-Request") !== "1"
    )
      return res
        .status(403)
        .json({ error: "Missing request verification header." });
    next();
  });
  const protect = (req, res, next) =>
    req.session.uid
      ? next()
      : res.status(401).json({ error: "Please sign in to continue." });
  const user = (id) =>
    db.prepare("SELECT id,name,email,bio,color FROM users WHERE id=?").get(id);
  const limit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 60,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: "Too many attempts. Try again in 15 minutes." },
  });
  app.get("/api/me", (req, res) =>
    res.json({ user: req.session.uid ? user(req.session.uid) : null }),
  );
  function login(req, res, u) {
    req.session.regenerate((e) => {
      if (e)
        return res.status(500).json({ error: "Could not create session." });
      req.session.uid = u.id;
      req.session.save((e) =>
        e
          ? res.status(500).json({ error: "Could not save session." })
          : res.json({ user: user(u.id) }),
      );
    });
  }
  app.post("/api/auth/register", limit, (req, res) => {
    const n = text(req.body.name, "Name", 60, 2),
      email = text(req.body.email, "Email", 254).toLowerCase(),
      p = text(req.body.password, "Password", 72, 8);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      fail("Enter a valid email address.");
    if (db.prepare("SELECT id FROM users WHERE email=?").get(email))
      fail("This email is already registered.", 409);
    const r = db
      .prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)")
      .run(n, email, bcrypt.hashSync(p, 10));
    login(req, res, { id: Number(r.lastInsertRowid) });
  });
  app.post("/api/auth/login", limit, (req, res) => {
    const email = text(req.body.email, "Email", 254).toLowerCase(),
      p = text(req.body.password, "Password", 72);
    const u = db.prepare("SELECT * FROM users WHERE email=?").get(email);
    if (!u || !bcrypt.compareSync(p, u.password))
      fail("Email or password is incorrect.", 401);
    login(req, res, u);
  });
  app.post("/api/auth/logout", (req, res) =>
    req.session.destroy(() => res.json({ ok: true })),
  );
  app.get("/api/users", protect, (req, res) => {
    const q = typeof req.query.q === "string" ? req.query.q.slice(0, 80) : "";
    res.json(
      db
        .prepare(
          "SELECT id,name,bio,color FROM users WHERE name LIKE ? ORDER BY name LIMIT 100",
        )
        .all(`%${q}%`),
    );
  });
  app.patch("/api/profile", protect, (req, res) => {
    db.prepare("UPDATE users SET name=?,bio=? WHERE id=?").run(
      text(req.body.name, "Name", 60, 2),
      text(req.body.bio ?? "", "Bio", 300, 0),
      req.session.uid,
    );
    res.json({ user: user(req.session.uid) });
  });
  if (!db.prepare("SELECT id FROM users LIMIT 1").get()) {
    const insert = db.prepare(
      "INSERT INTO users(name,email,password,bio,color) VALUES(?,?,?,?,?)",
    );
    const hash = bcrypt.hashSync("Demo12345!", 10);
    [
      [
        "Alex Morgan",
        "demo@example.com",
        "Making small things with a little more intention.",
        "#63795a",
      ],
      [
        "Maya Chen",
        "maya@example.com",
        "Designer. Collector of ideas. Coffee enthusiast.",
        "#b07855",
      ],
      [
        "Jordan Lee",
        "jordan@example.com",
        "Building for the web, one experiment at a time.",
        "#7361ad",
      ],
      [
        "Sam Rivera",
        "sam@example.com",
        "Product thinker and weekend photographer.",
        "#477b9d",
      ],
    ].forEach((u) => insert.run(u[0], u[1], hash, u[2], u[3]));
  }
  function finish() {
    app.use("/api", (req, res) =>
      res.status(404).json({ error: "Endpoint not found." }),
    );
    app.use(express.static(path.join(dir, "public"), {
      setHeaders: (res, filePath) => {
        // HTML and code must always revalidate so updates actually reach the
        // browser; photos may be cached.
        if (filePath.endsWith(".html")) res.set("Cache-Control", "no-store");
        else if (filePath.endsWith(".js") || filePath.endsWith(".css"))
          res.set("Cache-Control", "no-cache");
      },
    }));
    app.use((e, req, res, next) => {
      if (e.status >= 400 && e.status < 500)
        return res.status(e.status).json({ error: e.message });
      console.error(e);
      res
        .status(500)
        .json({ error: "Something went wrong. Please try again." });
    });
    return app;
  }
  return { app, db, protect, finish };
}
module.exports = { setup, fail, text, integer };
