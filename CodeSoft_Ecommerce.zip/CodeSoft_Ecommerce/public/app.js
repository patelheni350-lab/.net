let products = [],
  category = "All essentials",
  search = "",
  sort = "featured",
  view = "shop",
  currentProduct = null,
  imgIndex = 0,
  selColor = "";
let cart = {}; // key: "productId|Colour name"
try {
  cart = JSON.parse(localStorage.getItem("forma-cart") || "{}");
  if (!cart || typeof cart !== "object" || Array.isArray(cart)) cart = {};
} catch {
  cart = {};
}
const money = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n / 100);
const keyId = (k) => Number(String(k).split("|")[0]);
const keyColor = (k) => String(k).split("|").slice(1).join("|");
const colorList = (p) => {
  try {
    const l = JSON.parse(p.colors || "[]");
    return Array.isArray(l) ? l : [];
  } catch {
    return [];
  }
};
const imageList = (p, color) => {
  try {
    const raw = JSON.parse(p.images || "[]");
    const arr = Array.isArray(raw)
      ? raw
      : (color && raw[color]) || raw.default || [];
    return Array.isArray(arr) ? arr.filter((i) => i && i.src) : [];
  } catch {
    return [];
  }
};
const colorHex = (p, name) =>
  colorList(p).find((c) => c.name === name)?.hex || "#d8d2c4";
const shapes = {
  bag: `<path d="M104 78V60q36-26 72 0v18" fill="none" stroke="#857255" stroke-width="8"/><path d="M86 81q54-25 108 0l12 129q-62 22-131 0z" fill="#ac9b77"/><path d="M91 85q52-19 95 0l2 43H88z" fill="#c0b293"/><path d="M103 127h76v67h-76z" fill="#b6a684"/><path d="M109 129v24m64-24v24" stroke="#6a5e49" stroke-width="6"/><path d="M97 170h86" stroke="#927f5f" stroke-width="2"/><path d="M85 89l-5 113m111-113 9 112" stroke="#d3c5a6" stroke-width="3"/>`,
  headphones: `<path d="M79 153V111a61 61 0 01122 0v43" fill="none" stroke="#8c8378" stroke-width="18"/><path d="M80 121v-10a60 60 0 01120 0v11" fill="none" stroke="#ddd5c8" stroke-width="12"/><g transform="rotate(-12 82 169)"><rect x="57" y="131" width="47" height="76" rx="22" fill="#b3a999"/><rect x="59" y="140" width="16" height="59" rx="8" fill="#e4ded2"/></g><g transform="rotate(12 198 169)"><rect x="176" y="131" width="47" height="76" rx="22" fill="#b3a999"/><rect x="203" y="140" width="16" height="59" rx="8" fill="#e4ded2"/></g>`,
  lamp: `<ellipse cx="148" cy="216" rx="57" ry="12" fill="#6d7858"/><path d="M146 213V104" stroke="#747e60" stroke-width="10"/><path d="M86 113q0-67 60-67t60 67z" fill="#828d6b"/><ellipse cx="146" cy="113" rx="60" ry="10" fill="#d6caa4"/><ellipse cx="146" cy="111" rx="28" ry="7" fill="#f9e9ba"/>`,
  bottle: `<rect x="113" y="37" width="54" height="26" rx="8" fill="#425e50"/><path d="M114 61h52l12 27v118q0 16-38 16t-38-16V88z" fill="#7e9b89"/><path d="M114 89v113" stroke="#a8bdad" stroke-width="5" stroke-linecap="round"/><path d="M124 128h32" stroke="#d8e2d5" stroke-width="2"/><text x="140" y="145" font-size="8" fill="#e1e8dc" text-anchor="middle" letter-spacing="2">FORMA</text>`,
  chair: `<path d="M84 137l-9 86m110-86 13 86M99 181l-6 38m78-38 7 38" stroke="#917657" stroke-width="10"/><path d="M90 65q48-15 94 0l-3 81H95z" fill="#a99276"/><path d="M97 69q39-9 78 0l-2 62h-71z" fill="#c5b89d"/><path d="M79 146q58-18 118 0v28q-57 17-118 0z" fill="#bbae92"/><path d="M72 138l14-4m108 1 14 3" stroke="#917657" stroke-width="10" stroke-linecap="round"/>`,
  camera: `<rect x="56" y="84" width="168" height="111" rx="17" fill="#373d3f"/><path d="M66 84h148v27H66z" fill="#a1a6a2"/><path d="M114 83l9-19h40l13 19" fill="#686e6d"/><rect x="70" y="73" width="29" height="13" rx="4" fill="#4d5351"/><circle cx="145" cy="143" r="43" fill="#a4aaa5"/><circle cx="145" cy="143" r="35" fill="#343d3f"/><circle cx="145" cy="143" r="24" fill="#52676c"/><circle cx="145" cy="143" r="15" fill="#253b44"/><circle cx="137" cy="135" r="6" fill="#8aa5a5" opacity=".7"/><rect x="190" y="90" width="20" height="10" rx="2" fill="#ececdf"/>`,
  plant: `<path d="M139 147C87 132 81 93 91 79c26 3 49 29 48 68z" fill="#6f8561"/><path d="M141 146c-7-54 13-97 33-102 16 30 2 64-33 102z" fill="#5c7752"/><path d="M136 146c-40-9-73-13-80-42 34-12 66 6 80 42z" fill="#96a57c"/><path d="M142 149c23-53 54-63 76-52-8 27-41 49-76 52z" fill="#85996e"/><path d="M100 147h84l-13 66q-27 14-56 0z" fill="#bf896a"/><ellipse cx="142" cy="147" rx="42" ry="10" fill="#a67356"/><path d="M140 148v-15" stroke="#5c7752" stroke-width="7"/>`,
  keyboard: `<g transform="rotate(-13 140 130)"><rect x="36" y="84" width="208" height="101" rx="9" fill="#aa9d8a"/><rect x="36" y="79" width="208" height="98" rx="9" fill="#d6cdbd"/>${Array.from({ length: 4 }, (_, r) => Array.from({ length: 12 }, (_, c) => `<rect x="${44 + c * 16}" y="${87 + r * 18}" width="13" height="14" rx="2" fill="${c === 0 ? "#a0ab8b" : "#f4eee1"}"/>`).join("")).join("")}<rect x="92" y="145" width="77" height="14" rx="2" fill="#f5eee1"/></g>`,
  parcel: `<path d="M74 104l66-30 66 30v82l-66 30-66-30z" fill="#cbb99b"/><path d="M74 104l66 30 66-30M140 134v82" fill="none" stroke="#a5936f" stroke-width="7"/><path d="M106 89l66 30" stroke="#e8dfc9" stroke-width="6"/>`,
};
function art(p) {
  return `<svg viewBox="0 0 280 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${esc(p.name)} illustration"><rect width="280" height="260" fill="${p.color}"/><ellipse cx="142" cy="225" rx="77" ry="10" fill="#000" opacity=".065"/>${shapes[p.art] || shapes.parcel}</svg>`;
}
// Real product photography, layered over the illustration. If a photo is
// missing (404) the capture listener below swaps the illustration back in.
function photo(p, i = 0, cls = "") {
  const imgs = imageList(p),
    im = imgs[i];
  if (!im) return "";
  return `<img class="${cls}" src="${esc(im.src)}" alt="${esc(p.name)} — ${esc(im.label || "photo")}" loading="lazy" data-fallback="${esc(p.art || "parcel")}" data-color="${esc(p.color)}" data-name="${esc(p.name)}">`;
}
document.addEventListener(
  "error",
  (e) => {
    const t = e.target;
    if (!(t instanceof HTMLImageElement) || !t.dataset.fallback) return;
    const fill = t.dataset.color || "#e7e1d3",
      kind = t.dataset.fallback;
    if (kind === "campaign") {
      t.closest(".campaign-photo")?.classList.add("is-missing");
      t.remove();
      return;
    }
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 280 260");
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", (t.dataset.name || "Product") + " illustration");
    svg.innerHTML = `<rect width="280" height="260" fill="${fill}"/><ellipse cx="142" cy="225" rx="77" ry="10" fill="#000" opacity=".065"/>${shapes[kind] || shapes.parcel}`;
    svg.style.cssText = "width:100%;height:100%;display:block";
    t.replaceWith(svg);
  },
  true,
);
function cartCount() {
  return Object.entries(cart).reduce(
    (s, [k, q]) => s + (products.some((p) => p.id === keyId(k)) ? Number(q) || 0 : 0),
    0,
  );
}
function saveCart() {
  localStorage.setItem("forma-cart", JSON.stringify(cart));
  const n = $(".cart-count");
  if (n) n.textContent = cartCount();
}
function header() {
  return `<header class="topbar store-top"><a class="logo" href="./">forma<span style="color:#9ba98d">.</span></a><nav class="store-nav" aria-label="Store"><button class="${view === "shop" ? "active" : ""}" data-act="shop">Shop essentials</button><button class="${view === "orders" ? "active" : ""}" data-act="orders">My orders</button></nav><div class="topbar-actions"><label class="search-box" style="margin:0">${icon("search", 16)}<input id="store-search" aria-label="Search products" placeholder="Find your next favorite" value="${esc(search)}"></label><button class="icon-btn cart-btn" data-act="cart" aria-label="Shopping cart">${icon("bag", 22)}<span class="cart-count">${cartCount()}</span></button>${accountControl()}</div></header>`;
}
function footer() {
  return `<footer class="store-footer"><span class="logo">forma.</span><span>Less, but better. Essentials for a life well lived.</span></footer>`;
}
function render() {
  $("#app").innerHTML =
    header() +
    `<main class="store-main">${view === "shop" ? `<section class="hero"><div class="hero-copy"><div class="eyebrow">${icon("leaf", 13)} Thoughtfully chosen. Simply better.</div><h1>Everyday,<br>considered.</h1><p>Good design belongs in your every day.<br>Discover essentials made to feel right.</p><button class="btn primary" data-act="browse">Explore the collection ${icon("arrow", 15)}</button></div><img class="hero-photo" src="hero.jpg" alt="A sunlit desk with a sage lamp, headphones, a bottle, and a small plant"></section><div class="benefits"><div class="benefit">${icon("box")}<div><strong>A little less waiting</strong><span>Free delivery on every order</span></div></div><div class="benefit">${icon("leaf")}<div><strong>Made for the everyday</strong><span>Useful, beautiful, thoughtfully selected</span></div></div><div class="benefit">${icon("heart")}<div><strong>Find your kind of good</strong><span>Simple things. Lasting favorites.</span></div></div></div><section class="campaign"><div class="campaign-photo"><img src="img/p5-c.jpg" alt="A woman reading in an Arc lounge chair by a sunlit window" loading="lazy" data-fallback="campaign">${photo(currentAdProduct(), 2, "")}</div><div class="campaign-copy"><div class="eyebrow">${icon("heart", 13)} The campaign</div><h2>Made for<br>slow mornings.</h2><p>Our essentials don’t live on shelves — they live in real homes, real routines, real light. Every product is shot from every angle, on real people.</p><button class="btn" data-act="browse">Shop the campaign ${icon("arrow", 15)}</button></div></section><section id="collection"><div class="between collection-heading"><div><h2>The everyday edit</h2><p>A few good things to make your day a little better.</p></div><select id="sort" aria-label="Sort products"><option value="featured">Sort: Featured</option><option value="low">Price: Low to high</option><option value="high">Price: High to low</option></select></div><div class="categories">${["All essentials", "Everyday", "Home & living", "Technology"].map((c) => `<button class="category ${category === c ? "active" : ""}" data-act="category" data-value="${esc(c)}">${esc(c)}</button>`).join("")}<span class="result-count"></span></div><div class="product-grid" id="products"></div></section>` : view === "product" ? productPage() : '<div id="orders-content" class="loading">Loading your orders…</div>'}${footer()}</main>`;
  if (view === "shop") {
    renderProducts();
    $("#sort").value = sort;
  }
}
function currentAdProduct() {
  return products.find((p) => p.id === 5) || products[0] || { id: -1 };
}
function renderProducts() {
  let list = products.filter(
    (p) =>
      (category === "All essentials" || p.category === category) &&
      `${p.name} ${p.category}`.toLowerCase().includes(search.toLowerCase()),
  );
  if (sort !== "featured")
    list.sort((a, b) =>
      sort === "low" ? a.price - b.price : b.price - a.price,
    );
  $(".result-count").textContent = `${list.length} essentials`;
  $("#products").innerHTML = list.length
    ? list
        .map(
          (p) =>
            `<article class="product-card"><button class="product-art" style="background:${p.color}" data-act="detail" data-id="${p.id}">${art(p)}${photo(p, 0, "card-img")}${p.id < 3 ? `<span class="product-label">${p.id === 1 ? "Bestseller" : "A good find"}</span>` : ""}</button><div class="product-info"><div class="eyebrow">${p.category}</div><div class="between"><div><h3>${esc(p.name)}</h3><span class="price">${money(p.price)}</span></div><button class="add-circle" data-act="add" data-id="${p.id}" data-color="${esc(colorList(p)[0]?.name || "")}" aria-label="Add ${esc(p.name)} to cart" ${p.stock === 0 ? "disabled" : ""}>${icon("plus", 16)}</button></div><div class="card-swatches">${colorList(p).map((c) => `<span class="mini-swatch" style="background:${c.hex}" title="Comes in ${esc(c.name)}"></span>`).join("")}</div></div></article>`,
        )
        .join("")
    : '<div class="empty" style="grid-column:1/-1">No essentials found. Try another search or category.</div>';
}
function productPage() {
  const p = currentProduct,
    imgs = imageList(p, selColor),
    cur = Math.min(imgIndex, Math.max(0, imgs.length - 1)),
    colors = colorList(p);
  const tag = imgs[cur]
    ? imgs[cur].label + (selColor ? " · " + selColor : "")
    : "";
  return `<div class="product-page"><button class="text-btn small" data-act="shop">← Back to the collection</button><div class="product-detail"><div class="gallery"><div class="art-large gallery-main">${imgs.length && imgs[cur] ? `<img src="${esc(imgs[cur].src)}" alt="${esc(p.name)} — ${esc(tag)}" data-fallback="${esc(p.art)}" data-color="${esc(p.color)}" data-name="${esc(p.name)}"><span class="gallery-tag">${esc(tag)}</span>` : art(p)}</div>${imgs.length > 1 ? `<div class="thumbs">${imgs.map((im, i) => `<button class="thumb ${i === cur ? "active" : ""}" data-act="img" data-i="${i}" aria-label="${esc(im.label)}"><img src="${esc(im.src)}" alt="" loading="lazy" data-fallback="none"></button>`).join("")}</div>` : ""}</div><div class="detail-copy"><span class="pill">${p.category}</span><h1>${esc(p.name)}</h1><p class="detail-price">${money(p.price)}</p><p>${esc(p.description)}</p>${colors.length ? `<div class="color-block"><div class="row small"><strong>Colour</strong><span class="muted">${esc(selColor)}</span></div><div class="swatches">${colors.map((c) => `<button class="swatch ${selColor === c.name ? "active" : ""}" style="--c:${c.hex}" data-act="swatch" data-value="${esc(c.name)}" aria-label="Colour ${esc(c.name)}" title="${esc(c.name)}"></button>`).join("")}</div></div>` : ""}<div class="stock">${p.stock > 0 ? "● " + p.stock + " available · Free delivery" : "Currently sold out"}</div><button class="btn primary full" data-act="add" data-id="${p.id}" ${p.stock === 0 ? "disabled" : ""}>${icon("bag", 17)} Add to bag</button><div class="divider"></div><div class="row small muted">${icon("leaf", 18)} Thoughtfully selected for the everyday.</div><p class="small mt">Photography includes studio shots, alternate angles and real-life campaign images. This is a demonstration store — no payment is collected and no items are shipped.</p></div></div></div>`;
}
function detail(p) {
  currentProduct = p;
  imgIndex = 0;
  selColor = colorList(p)[0]?.name || "";
  view = "product";
  render();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function add(id, color = "") {
  const p = products.find((p) => p.id === id),
    key = id + "|" + (color || ""),
    q = Number(cart[key] || 0);
  if (!p || q >= Math.min(20, p.stock))
    return toast("You’ve reached the available quantity.");
  cart[key] = q + 1;
  saveCart();
  toast(`${p.name}${color ? " · " + color : ""} added to your bag.`);
}
function lines() {
  return Object.entries(cart)
    .map(([k, q]) => {
      const p = products.find((x) => x.id === keyId(k));
      return p ? { ...p, quantity: Number(q), color: keyColor(k) } : null;
    })
    .filter(Boolean);
}
function total() {
  return lines().reduce((s, p) => s + p.price * p.quantity, 0);
}
function showCart() {
  const l = lines();
  openModal(
    "Your bag",
    l.length
      ? `${l.map((p) => `<div class="cart-line">${art(p)}<div><h4>${esc(p.name)}</h4><span class="small muted">${money(p.price)}</span>${p.color ? `<span class="color-tag"><i class="color-chip" style="background:${colorHex(p, p.color)}"></i>${esc(p.color)}</span>` : ""}<button class="text-btn small" style="display:block;margin-top:5px" data-act="remove" data-key="${esc(p.id + "|" + p.color)}">Remove</button></div><div class="qty"><button class="icon-btn" data-act="qty" data-key="${esc(p.id + "|" + p.color)}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${p.quantity}</span><button class="icon-btn" data-act="qty" data-key="${esc(p.id + "|" + p.color)}" data-delta="1" aria-label="Increase quantity">+</button></div></div>`).join("")}<div class="summary"><div class="between small"><span>Delivery</span><span>On us</span></div><div class="between"><strong>Total</strong><strong>${money(total())}</strong></div></div><button class="btn primary full mt" data-act="checkout">Continue to checkout ${icon("arrow", 17)}</button><p class="small muted center mt">Demo checkout · No payment will be collected</p>`
      : `<div class="empty">${icon("bag", 42)}<h3>A little room for something good.</h3><p>Your bag is empty.</p><button class="btn primary" data-act="close">Keep exploring</button></div>`,
  );
}
function checkout() {
  if (!requireUser()) return;
  if (!lines().length) return showCart();
  openModal(
    "The final little details",
    `<p class="muted">Delivering to ${esc(me.name)}. Add your complete delivery address below.</p><form data-form="checkout"><label>Delivery address<textarea name="address" required minlength="15" maxlength="600" rows="4" placeholder="House / flat number, street, city, state and PIN code"></textarea></label><div class="checkout-note">This is a demo order. No payment is collected and no items will be shipped.</div><div class="summary between"><strong>Total · ${cartCount()} items</strong><strong>${money(total())}</strong></div><div class="form-error" role="alert"></div><button class="btn primary full" type="submit">Place demo order ${icon("arrow", 17)}</button></form>`,
  );
}
async function showOrders() {
  if (!requireUser()) return;
  history.replaceState(null, "", location.pathname);
  view = "orders";
  render();
  const orders = await api("orders");
  $("#orders-content").className = "";
  $("#orders-content").innerHTML =
    `<div class="order-intro"><span class="eyebrow muted">Your essentials, on their way</span><h1 class="mt">My orders</h1><p class="muted">A little history of your good finds.</p></div>${orders.length ? orders.map((o) => `<article class="card order-card"><div class="between"><div><h3>Order #${String(o.id).padStart(5, "0")}</h3><span class="small muted">${when(o.created_at)}</span></div><span class="pill">${icon("check", 13)} ${o.status}</span></div>${o.items.map((i) => `<div class="order-item"><span>${esc(i.name)}${i.color ? ` · <em class="muted">${esc(i.color)}</em>` : ""} <span class="muted">× ${i.quantity}</span></span><span>${money(i.price * i.quantity)}</span></div>`).join("")}<div class="divider"></div><div class="between"><span class="small muted prewrap">${esc(o.address)}</span><strong>${money(o.total)}</strong></div></article>`).join("") : `<div class="card empty">${icon("box", 40)}<h3>Your first good find is waiting.</h3><p>No orders yet.</p><button class="btn primary" data-act="shop">Explore essentials</button></div>`}`;
}
window.handleAction = async (a, b) => {
  if (a === "shop") {
    history.replaceState(null, "", location.pathname);
    view = "shop";
    render();
  }
  if (a === "browse") $("#collection").scrollIntoView({ behavior: "smooth" });
  if (a === "category") {
    category = b.dataset.value;
    $$(".category").forEach((x) => x.classList.toggle("active", x === b));
    renderProducts();
  }
  if (a === "img") {
    imgIndex = Number(b.dataset.i);
    render();
  }
  if (a === "swatch") {
    selColor = b.dataset.value;
    imgIndex = 0;
    render();
  }
  if (a === "detail") {
    history.replaceState(null, "", "#product-" + Number(b.dataset.id));
    await hashProduct();
  }
  if (a === "add")
    add(Number(b.dataset.id), b.dataset.color ?? selColor ?? "");
  if (a === "cart") showCart();
  if (a === "remove") {
    delete cart[b.dataset.key];
    saveCart();
    showCart();
  }
  if (a === "qty") {
    const key = b.dataset.key;
    if (b.dataset.delta === "1")
      add(keyId(key), keyColor(key));
    else {
      cart[key]--;
      if (cart[key] <= 0) delete cart[key];
      saveCart();
    }
    showCart();
  }
  if (a === "checkout") checkout();
  if (a === "orders") await showOrders();
};
window.handleForm = async (type, v) => {
  if (type === "checkout") {
    const o = await api("orders", "POST", {
      address: v.address,
      items: lines().map((p) => ({
        id: p.id,
        quantity: p.quantity,
        color: p.color,
      })),
    });
    cart = {};
    saveCart();
    products = await api("products");
    render();
    openModal(
      "A good choice.",
      `<div class="center"><div class="success-icon">${icon("check", 30)}</div><h2>Your demo order is confirmed.</h2><p class="muted">Order #${String(o.id).padStart(5, "0")} · ${money(o.total)}</p><p class="small muted">No payment was collected. View the order in your order history.</p><button class="btn primary full" data-act="view-order">View my orders</button></div>`,
    );
  }
};
const storeActions = window.handleAction;
window.handleAction = async (a, b, e) => {
  if (a === "view-order") {
    closeModal();
    await showOrders();
  } else await storeActions(a, b, e);
};
window.onAuth = async () => {
  if (view === "orders" && me) await showOrders();
  else {
    view = "shop";
    render();
  }
};
document.addEventListener("input", (e) => {
  if (e.target.id === "store-search") {
    search = e.target.value;
    if (view === "shop") renderProducts();
  }
});
document.addEventListener("change", (e) => {
  if (e.target.id === "sort") {
    sort = e.target.value;
    renderProducts();
  }
});
async function hashProduct() {
  if (location.hash.startsWith("#product-")) {
    try {
      detail(await api("products/" + Number(location.hash.slice(9))));
    } catch (e) {
      toast(e.message);
    }
  }
}
window.addEventListener("hashchange", hashProduct);
(async () => {
  try {
    [products, { user: me }] = await Promise.all([api("products"), api("me")]);
    for (const [k, q] of Object.entries(cart))
      if (!Number.isInteger(q) || q < 1 || q > 20 || !products.some((p) => p.id === keyId(k)))
        delete cart[k];
    render();
    await hashProduct();
  } catch (e) {
    $("#app").innerHTML =
      `<div class="empty"><h2>We couldn’t open the store.</h2><p>${esc(e.message)}</p><a class="btn" href="./">Try again</a></div>`;
  }
})();
