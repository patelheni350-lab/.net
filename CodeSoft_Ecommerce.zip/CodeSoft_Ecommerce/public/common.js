const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const icons = {
  grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
  bag: "M5 7h14l1 14H4L5 7z M9 8V6a3 3 0 016 0v2",
  search: "M21 21l-5-5 M18 10a8 8 0 11-16 0 8 8 0 0116 0",
  arrow: "M4 12h16 M14 6l6 6-6 6",
  plus: "M12 5v14 M5 12h14",
  close: "M6 6l12 12 M18 6L6 18",
  user: "M20 21v-2a7 7 0 00-14 0v2 M16 7a4 4 0 11-8 0 4 4 0 018 0",
  heart:
    "M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 00-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 000-7.8z",
  comment: "M21 11a9 9 0 01-9 9H3l2-5a9 9 0 1116-4z",
  people:
    "M16 21v-2a6 6 0 00-12 0v2 M14 6a4 4 0 11-8 0 4 4 0 018 0 M17 3a4 4 0 010 8 M20 21v-3a5 5 0 00-3-4",
  home: "M3 10l9-7 9 7v11h-7v-7h-4v7H3z",
  check: "M5 12l4 4L19 6",
  logout: "M9 3H4v18h5 M9 12h12 M17 8l4 4-4 4",
  box: "M3 7l9-4 9 4-9 4-9-4z M3 7v10l9 4 9-4V7 M12 11v10",
  leaf: "M20 3c1 11-5 17-14 15C2 9 9 3 20 3z M4 21L16 8",
  clock: "M21 12a9 9 0 11-18 0 9 9 0 0118 0 M12 7v5l3 2",
  chevron: "M9 5l7 7-7 7",
  edit: "M16 3l5 5L9 20l-6 1 1-6L16 3z",
  trash: "M3 6h18 M9 6V3h6v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7",
  board: "M3 3h18v18H3z M9 3v18 M15 3v18",
  spark: "M12 2l3 7 7 3-7 3-3 7-3-7-7-3 7-3 3-7z",
  mail: "M3 5h18v14H3z M3 5l9 8 9-8",
  filter: "M3 5h18 M6 12h12 M10 19h4",
};
function icon(name, size = 20) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${icons[name] || icons.grid}"/></svg>`;
}
function avatar(u, size = "") {
  const initials = (u.name || "?")
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
  return `<span class="avatar ${size}" style="--avatar:${esc(u.color || "#7361ad")}">${esc(initials)}</span>`;
}
let me = null;
async function api(path, method = "GET", body) {
  const r = await fetch("api/" + path, {
    method,
    headers: { "Content-Type": "application/json", "X-App-Request": "1" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data;
  try {
    data = await r.json();
  } catch {
    throw Error("Could not reach the server. Please try again.");
  }
  if (!r.ok) throw Error(data.error || "Request failed.");
  return data;
}
function toast(msg) {
  let t = $("#toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "toast";
    t.setAttribute("role", "status");
    document.body.append(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => t.classList.remove("show"), 3800);
}
function openModal(title, body, wide = false) {
  let d = $("#modal");
  if (!d) {
    d = document.createElement("dialog");
    d.id = "modal";
    document.body.append(d);
    d.addEventListener("click", (e) => {
      if (e.target === d) {
        const b = d.getBoundingClientRect();
        if (
          e.clientX < b.left ||
          e.clientX > b.right ||
          e.clientY < b.top ||
          e.clientY > b.bottom
        )
          d.close();
      }
    });
  }
  d.className = wide ? "wide" : "";
  d.innerHTML = `<div class="modal-head"><h2>${esc(title)}</h2><button class="icon-btn" data-act="close" aria-label="Close dialog">${icon("close")}</button></div><div class="modal-body">${body}</div>`;
  if (!d.open) d.showModal();
}
function closeModal() {
  $("#modal")?.close();
}
function auth(mode = "login") {
  openModal(
    mode === "login" ? "Welcome back" : "A fresh start",
    `<p class="muted">${mode === "login" ? "Sign in to make yourself at home." : "Create an account to get started."}</p><form data-form="auth" data-mode="${mode}">${mode === "register" ? '<label>Your name<input name="name" autocomplete="name" required minlength="2" maxlength="60" placeholder="Alex Morgan"></label>' : ""}<label>Email address<input type="email" name="email" autocomplete="email" required placeholder="you@example.com"></label><label>Password<input type="password" name="password" autocomplete="${mode === "login" ? "current-password" : "new-password"}" minlength="${mode === "login" ? 1 : 8}" maxlength="72" required placeholder="${mode === "login" ? "Enter your password" : "At least 8 characters"}"></label><div class="form-error" role="alert"></div><button class="btn primary full" type="submit">${mode === "login" ? "Sign in" : "Create account"} ${icon("arrow", 17)}</button></form><div class="auth-divider">or take a look around</div><button class="btn full" data-act="demo">Explore with demo account</button><p class="center small muted">${mode === "login" ? "New here?" : "Already have an account?"} <button class="text-btn" data-act="auth" data-mode="${mode === "login" ? "register" : "login"}">${mode === "login" ? "Create an account" : "Sign in"}</button></p>`,
  );
}
function requireUser() {
  if (me) return true;
  auth();
  return false;
}
function accountControl() {
  return me
    ? `<button class="account-btn" data-act="account">${avatar(me)}<span>${esc(me.name.split(" ")[0])}</span>${icon("chevron", 14)}</button>`
    : `<button class="btn" data-act="auth">Sign in ${icon("arrow", 16)}</button>`;
}
function editProfile() {
  openModal(
    "Your profile",
    `<form data-form="profile"><label>Full name<input name="name" value="${esc(me.name)}" required minlength="2" maxlength="60"></label><label>About you<textarea name="bio" maxlength="300" rows="3">${esc(me.bio)}</textarea></label><p class="small muted">${esc(me.email)}</p><div class="form-error" role="alert"></div><button class="btn primary full">Save changes</button></form><button class="btn danger full mt" data-act="logout">${icon("logout", 17)} Sign out</button>`,
  );
}
function when(v) {
  const d = new Date(v.replace(" ", "T") + "Z"),
    n = Math.max(0, (Date.now() - d) / 60000);
  if (n < 1) return "Just now";
  if (n < 60) return `${Math.floor(n)}m ago`;
  if (n < 1440) return `${Math.floor(n / 60)}h ago`;
  return d.toLocaleDateString("en-IN", { month: "short", day: "numeric" });
}
async function refreshAuth() {
  me = (await api("me")).user;
  if (window.onAuth) await window.onAuth();
}
document.addEventListener("click", async (e) => {
  const b = e.target.closest("[data-act]");
  if (!b || b.disabled) return;
  const act = b.dataset.act;
  try {
    if (act === "close") closeModal();
    else if (act === "auth") auth(b.dataset.mode);
    else if (act === "account") editProfile();
    else if (act === "demo") {
      b.disabled = true;
      me = (
        await api("auth/login", "POST", {
          email: "demo@example.com",
          password: "Demo12345!",
        })
      ).user;
      closeModal();
      await window.onAuth?.();
      toast("Welcome, Alex. You’re using the demo account.");
    } else if (act === "logout") {
      await api("auth/logout", "POST", {});
      me = null;
      closeModal();
      await window.onAuth?.();
      toast("You have been signed out.");
    } else if (window.handleAction) await window.handleAction(act, b, e);
  } catch (err) {
    toast(err.message);
  } finally {
    b.disabled = false;
  }
});
document.addEventListener("submit", async (e) => {
  const form = e.target.closest("form[data-form]");
  if (!form) return;
  e.preventDefault();
  const submit = $('button[type="submit"],button:not([type])', form);
  if (submit?.disabled) return;
  if (submit) submit.disabled = true;
  const values = Object.fromEntries(new FormData(form));
  const error = $(".form-error", form);
  if (error) error.textContent = "";
  try {
    if (form.dataset.form === "auth") {
      me = (await api("auth/" + form.dataset.mode, "POST", values)).user;
      closeModal();
      await window.onAuth?.();
      toast("You’re signed in. Welcome!");
    } else if (form.dataset.form === "profile") {
      me = (await api("profile", "PATCH", values)).user;
      closeModal();
      await window.onAuth?.();
      toast("Profile updated.");
    } else await window.handleForm?.(form.dataset.form, values, form);
  } catch (err) {
    if (error) error.textContent = err.message;
    else toast(err.message);
  } finally {
    if (submit) submit.disabled = false;
  }
});
