const { setup, fail, text, integer } = require("./backend");
const path = require("path");
const fs = require("fs");
function createApp() {
  const { app, db, protect, finish } = setup(__dirname, "store");
  db.exec(`CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,price INTEGER NOT NULL,description TEXT NOT NULL,art TEXT NOT NULL,color TEXT NOT NULL,stock INTEGER NOT NULL,colors TEXT NOT NULL DEFAULT '[]',images TEXT NOT NULL DEFAULT '[]');
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),total INTEGER NOT NULL,address TEXT NOT NULL,status TEXT DEFAULT 'Confirmed',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL REFERENCES orders(id),product_id INTEGER NOT NULL REFERENCES products(id),name TEXT NOT NULL,price INTEGER NOT NULL,quantity INTEGER NOT NULL,color TEXT NOT NULL DEFAULT '');`);
  // Migrate databases created before colour variants / photo galleries existed.
  const cols = (t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
  if (!cols("products").includes("colors"))
    db.exec("ALTER TABLE products ADD COLUMN colors TEXT NOT NULL DEFAULT '[]'");
  if (!cols("products").includes("images"))
    db.exec("ALTER TABLE products ADD COLUMN images TEXT NOT NULL DEFAULT '[]'");
  if (!cols("order_items").includes("color"))
    db.exec("ALTER TABLE order_items ADD COLUMN color TEXT NOT NULL DEFAULT ''");
  // The catalog is owned by the app: keep it in sync on every boot while
  // preserving live stock levels for rows that already exist.
  const C = (name, hex) => ({ name, hex });
  // Per-colour photography. The canonical gallery lives at img/pN-a|b|c.jpg;
  // colourways live at img/pN-{colour-slug}-a|b|c.jpg and are only offered
  // once all three shots exist, so galleries can be added gradually.
  const imgDir = path.join(__dirname, "public", "img");
  const has = (f) => fs.existsSync(path.join(imgDir, f));
  const shotList = (id, slug) =>
    ["a", "b", "c"]
      .map((x, i) => ({
        src: `img/p${id}${slug ? "-" + slug : ""}-${x}.jpg`,
        label: ["Front view", "From another angle", "In real life"][i],
      }))
      .filter((im) => has(im.src.replace("img/", "")));
  const imagesFor = (id, colors) => {
    const out = { default: shotList(id, "") };
    for (const c of colors) {
      const slug = c.name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const shots = shotList(id, slug);
      if (shots.length === 3) out[c.name] = shots;
    }
    return out;
  };
  const upsert = db.prepare(
    `INSERT INTO products(id,name,category,price,description,art,color,stock,colors,images)
     VALUES(@id,@name,@category,@price,@description,@art,@color,@stock,@colors,@images)
     ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,price=excluded.price,
       description=excluded.description,colors=excluded.colors,images=excluded.images`,
  );
  [
    {
      id: 1,
      name: "Everyday backpack",
      category: "Everyday",
      price: 249900,
      description:
        "A thoughtfully designed canvas backpack with padded laptop storage, durable brass details and room for your daily essentials. 18 L capacity.",
      art: "bag",
      color: "#e5e5d9",
      stock: 40,
      colors: [C("Olive", "#6f7d4f"), C("Sand", "#c8b797"), C("Charcoal", "#3b3b38")],
    },
    {
      id: 2,
      name: "Studio headphones",
      category: "Technology",
      price: 499900,
      description:
        "Find your focus with comfortable over-ear headphones, rich balanced audio and up to 30 hours of wireless listening. Includes a USB-C charging cable.",
      art: "headphones",
      color: "#e5ded4",
      stock: 30,
      colors: [C("Cream", "#e8dfce"), C("Sage", "#9aa88c"), C("Black", "#2e2c29")],
    },
    {
      id: 3,
      name: "Terra desk lamp",
      category: "Home & living",
      price: 329900,
      description:
        "A warm pool of light for your favorite corner. Powder-coated metal with an adjustable shade and a warm LED bulb included.",
      art: "lamp",
      color: "#ecdccd",
      stock: 25,
      colors: [C("Olive", "#708150"), C("Terracotta", "#c26d4b"), C("Cream", "#eae0cc")],
    },
    {
      id: 4,
      name: "The daily bottle",
      category: "Everyday",
      price: 89900,
      description:
        "Keep your everyday ritual close. A 750 ml insulated stainless-steel bottle that keeps drinks cold for 24 hours or hot for 12.",
      art: "bottle",
      color: "#dce5dc",
      stock: 60,
      colors: [C("Sage", "#8fa08a"), C("Midnight", "#33322f"), C("Clay", "#c07b5b")],
    },
    {
      id: 5,
      name: "Arc lounge chair",
      category: "Home & living",
      price: 1299900,
      description:
        "A quiet place to pause. A solid wood frame and softly upholstered seat bring comfort and timeless shape to your space.",
      art: "chair",
      color: "#e8e2d7",
      stock: 12,
      colors: [C("Boucle", "#e6dcc8"), C("Cocoa", "#8a6a52"), C("Sage", "#97a58f")],
    },
    {
      id: 6,
      name: "Pocket camera",
      category: "Technology",
      price: 899900,
      description:
        "Capture the ordinary beautifully. A compact 24 MP digital camera with a fixed lens, rechargeable battery and a woven wrist strap.",
      art: "camera",
      color: "#dcdfe5",
      stock: 15,
      colors: [C("Silver", "#c9c9c4"), C("Charcoal", "#2b2a28"), C("Forest", "#4c5a48")],
    },
    {
      id: 7,
      name: "Little green friend",
      category: "Home & living",
      price: 69900,
      description:
        "A hardy indoor succulent in a handcrafted ceramic pot. Easy to care for, lovely to live with. Pot diameter approximately 12 cm.",
      art: "plant",
      color: "#e6e5d6",
      stock: 45,
      colors: [C("Terracotta", "#be6e4c"), C("Stone", "#b9b4a8"), C("Cream", "#e9dfc9")],
    },
    {
      id: 8,
      name: "Minimal keyboard",
      category: "Technology",
      price: 349900,
      description:
        "A compact wireless keyboard with quiet tactile keys, a rechargeable battery and a clean layout. Compatible with Windows and macOS.",
      art: "keyboard",
      color: "#e2ddd9",
      stock: 22,
      colors: [C("Cream", "#ede6d6"), C("Grey", "#9c9c97"), C("Charcoal", "#3a3936")],
    },
    {
      id: 9,
      name: "Market tote",
      category: "Everyday",
      price: 129900,
      description:
        "Sturdy natural canvas tote with long handles and a hidden inner pocket. Carries the farmer's market, the library and everything in between.",
      art: "parcel",
      color: "#e9e2d2",
      stock: 50,
      colors: [C("Natural", "#d8ccb2"), C("Olive", "#77855a"), C("Charcoal", "#3c3b38")],
    },
    {
      id: 10,
      name: "Pour-over coffee set",
      category: "Home & living",
      price: 219900,
      description:
        "A slow morning ritual: ceramic cone dripper and glass carafe in a warm sand glaze. Brews 4 cups. Dishwasher friendly.",
      art: "parcel",
      color: "#f0e7d8",
      stock: 28,
      colors: [C("Sand", "#cdbba0"), C("Ivory", "#efeae0"), C("Charcoal", "#43413d")],
    },
    {
      id: 11,
      name: "Pebble earbuds",
      category: "Technology",
      price: 199900,
      description:
        "Truly wireless earbuds with a soft pebble-shaped charging case, warm balanced sound and 24 hours of listening on the go.",
      art: "parcel",
      color: "#ece4d6",
      stock: 35,
      colors: [C("Cream", "#e9e1d2"), C("Sage", "#9fac97"), C("Graphite", "#353431")],
    },
    {
      id: 12,
      name: "Linen throw",
      category: "Home & living",
      price: 179900,
      description:
        "A soft stone-washed linen throw with hand-knotted fringe. Perfect for slow evenings on the sofa. 130 × 180 cm.",
      art: "parcel",
      color: "#efe8da",
      stock: 30,
      colors: [C("Oat", "#dacbb0"), C("Moss", "#7c8a6e"), C("Rust", "#b3674a")],
    },
  ].forEach((p) =>
    upsert.run({
      ...p,
      colors: JSON.stringify(p.colors),
      images: JSON.stringify(imagesFor(p.id, p.colors)),
    }),
  );
  // The catalog is app-owned: drop rows left over from older versions
  // (e.g. duplicated seeds) so the store always shows exactly these 12.
  db.prepare(
    `DELETE FROM products WHERE id NOT IN (${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].join(",")})`,
  ).run();
  app.get("/api/products", (req, res) =>
    res.json(db.prepare("SELECT * FROM products ORDER BY id").all()),
  );
  app.get("/api/products/:id", (req, res) => {
    const p = db
      .prepare("SELECT * FROM products WHERE id=?")
      .get(integer(req.params.id, "product"));
    if (!p) fail("Product not found.", 404);
    res.json(p);
  });
  app.get("/api/orders", protect, (req, res) => {
    res.json(
      db
        .prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC")
        .all(req.session.uid)
        .map((o) => ({
          ...o,
          items: db
            .prepare(
              "SELECT name,price,quantity,color FROM order_items WHERE order_id=?",
            )
            .all(o.id),
        })),
    );
  });
  app.post("/api/orders", protect, (req, res) => {
    const address = text(req.body.address, "Delivery address", 600, 15),
      items = req.body.items;
    if (!Array.isArray(items) || !items.length || items.length > 30)
      fail("Your cart must contain 1–30 products.");
    const result = db.transaction(() => {
      const seen = new Set();
      const lines = items.map((i) => {
        const id = integer(i.id, "product"),
          q = integer(i.quantity, "quantity", 1, 20);
        const color = i.color ? text(i.color, "Colour", 40) : "";
        if (seen.has(id + "|" + color.toLowerCase())) fail("Duplicate cart item.");
        seen.add(id + "|" + color.toLowerCase());
        const p = db.prepare("SELECT * FROM products WHERE id=?").get(id);
        if (!p) fail("A product no longer exists.");
        if (color) {
          const ok = JSON.parse(p.colors || "[]").some(
            (c) => c.name.toLowerCase() === color.toLowerCase(),
          );
          if (!ok) fail(`${p.name} does not come in ${color}.`);
        }
        if (p.stock < q) fail(`${p.name}: only ${p.stock} left in stock.`);
        return { ...p, quantity: q, color };
      });
      const total = lines.reduce((s, i) => s + i.price * i.quantity, 0);
      const id = Number(
        db
          .prepare("INSERT INTO orders(user_id,total,address) VALUES(?,?,?)")
          .run(req.session.uid, total, address).lastInsertRowid,
      );
      for (const i of lines) {
        db.prepare(
          "INSERT INTO order_items(order_id,product_id,name,price,quantity,color) VALUES(?,?,?,?,?,?)",
        ).run(id, i.id, i.name, i.price, i.quantity, i.color);
        db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(
          i.quantity,
          i.id,
        );
      }
      return { id, total, status: "Confirmed" };
    })();
    res.status(201).json(result);
  });
  return finish();
}
module.exports = createApp;
if (require.main === module)
  createApp().listen(process.env.PORT || 3001, "0.0.0.0", () =>
    console.log("E-commerce ready on port " + (process.env.PORT || 3001)),
  );
